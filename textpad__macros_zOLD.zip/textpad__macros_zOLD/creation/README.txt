***NEED TO MOVE z_dynamically_created_files to macros/xbnpe_dynamically_created***

Requirements:

- keys-with-modifier phrases exist.
- Only one key command is created with each macro. Alternative key commands must be created elsewhere.


Notes:

MAIN.px.txt phrases, after importing into PhraseExpress, should have their contents removed from the MAIN.px folder, and placed into its parent.